#Assignment 2 @ ML760
#Anmol Mohanty
# NaiveBayes & TAN
Implementations of both Naive Bayes as well as TAN.


## Requirements
Python 2.7

## Important Scripts
bayesi : Script that calls bayes.py 
bayes.py : Contains the implementation of Naive Bayes as well as TAN
.arff : Sample data files 

## Usage
Command to run the script: ./bayes train-set-file test-set-file n|t

* n: Naive Bayes
* t: TAN 

TAN algorithm uses Prim's algorithm to find the maximal spanning tree.
